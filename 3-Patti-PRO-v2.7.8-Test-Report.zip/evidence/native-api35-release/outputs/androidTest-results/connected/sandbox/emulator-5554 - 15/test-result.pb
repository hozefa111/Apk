
2�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp:onlineSessionCascadeRemovesLinkedRoundsAndKeepsOtherScores2�����ω�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-onlineSessionCascadeRemovesLinkedRoundsAndKeepsOtherScores.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp8largeClearRestoreAndInterruptedCommitRecoverAfterRestart2��������:ɻ����4"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-largeClearRestoreAndInterruptedCommitRecoverAfterRestart.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp4sdkCodecPreservesAllArchiveTypesAndLiteralFieldNames2ɻ�����5:ʻ������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-sdkCodecPreservesAllArchiveTypesAndLiteralFieldNames.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp1clearRequiresCurrentBackupAndCanRestoreEverything2ʻ���ٱ�:ϻ������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-clearRequiresCurrentBackupAndCanRestoreEverything.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp$staleVersionCannotOverwriteNewerEdit2ϻ������:ӻ�����4"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-staleVersionCannotOverwriteNewerEdit.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp.roundRetryAndPayloadConflictAndVersionedDelete2ӻ�����7:ػ������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-roundRetryAndPayloadConflictAndVersionedDelete.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp8externalEditArrivesDirectlyAndOldDialogCannotOverwriteIt2ػ�����:ۻ����ۂ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-externalEditArrivesDirectlyAndOldDialogCannotOverwriteIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp1playerChartAndSelectionsSurviveActivityRecreation2ۻ����Ճ:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-playerChartAndSelectionsSurviveActivityRecreation.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp=analyticsControlsAndLongNamesRemainUsableAtLargeFontLandscape2������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-analyticsControlsAndLongNamesRemainUsableAtLargeFontLandscape.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp+sessionScopeAndEmptyHistoryDoNotInventStats2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-sessionScopeAndEmptyHistoryDoNotInventStats.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp0everyAdvancedViewRendersAndKeepsFiltersReachable2��������:�������}"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-everyAdvancedViewRendersAndKeepsFiltersReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp:fortySevenRoundHistoryUsesCardsAndKeepsEveryRoundReachable2�������:�������G"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-fortySevenRoundHistoryUsesCardsAndKeepsEveryRoundReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp5largeFontLandscapeKeepsHistoryAndShareActionsOnScreen2�������H:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-largeFontLandscapeKeepsHistoryAndShareActionsOnScreen.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp5detailsKeepNegativeAndZeroScoresDistinctWithLongNames2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-detailsKeepNegativeAndZeroScoresDistinctWithLongNames.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp1motionPreferencePersistsThroughActivityRecreation2��������:�������Y"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-motionPreferencePersistsThroughActivityRecreation.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp>systemAnimationOffOverridesFullAndReducedLeavesFinalReadableUi2������]:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-systemAnimationOffOverridesFullAndReducedLeavesFinalReadableUi.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp<pauseCancelsMotionRestoresFinalScoreAndDoesNotReplayOnResume2�������:�����߳�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-pauseCancelsMotionRestoresFinalScoreAndDoesNotReplayOnResume.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp7sessionCelebrationCanBeSkippedAndHistoryDoesNotReplayIt2������:¼����"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-sessionCelebrationCanBeSkippedAndHistoryDoesNotReplayIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp@confirmedLiveSnapshotAnimatesScoresRanksAndNeverReplaysReconnect2¼����޾:Ǽ���Ʀ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-confirmedLiveSnapshotAnimatesScoresRanksAndNeverReplaysReconnect.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
x
NativeNavigationTest"com.hozefa.threepattipro.nativeapp fullRoundFormSaveAndSharePreview2Ǽ���Ϡ�:ݼ������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-fullRoundFormSaveAndSharePreview.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeNavigationTest"com.hozefa.threepattipro.nativeapp)restoredLoginDuringDialogShowDoesNotCrash2ݼ������:޼������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-restoredLoginDuringDialogShowDoesNotCrash.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
u
NativeNavigationTest"com.hozefa.threepattipro.nativeappnativeScreensSearchAndSettings2޼���ω�:�����ߘ%"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-nativeScreensSearchAndSettings.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeNavigationTest"com.hozefa.threepattipro.nativeapp.navigationAndSettingsRemainUsableWithLargeText2������':��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-navigationAndSettingsRemainUsableWithLargeText.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp5sdkOfflineRestartKeepsSavedTableReadOnlyAndReconnects2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-sdkOfflineRestartKeepsSavedTableReadOnlyAndReconnects.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp7oldRestCooldownDoesNotBlockHealthySdkAndNoMinutePolling2�������:ν����ǳ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-oldRestCooldownDoesNotBlockHealthySdkAndNoMinutePolling.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp@quotaCooldownSurvivesRestartAndRefreshThenRecoversWithoutWriting2ν������:Ͻ����Ԓ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-quotaCooldownSurvivesRestartAndRefreshThenRecoversWithoutWriting.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp<quotaScreenReplacesEndlessLoadingAndKeepsCachedTableReadable2Ͻ������:ѽ����τ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-quotaScreenReplacesEndlessLoadingAndKeepsCachedTableReadable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp2largeTextLandscapeKeepsScoreboardControlsReachable2ѽ���߳�:ܽ������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-largeTextLandscapeKeepsScoreboardControlsReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp7currentSessionWithoutActiveSessionShowsNoInventedScores2ܽ����:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-currentSessionWithoutActiveSessionShowsNoInventedScores.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp6compactPodiumHasNoClippedNamesOrScoresAndOpensProfiles2�������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-compactPodiumHasNoClippedNamesOrScoresAndOpensProfiles.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp5tiesHaveJointCrownsAndTheFourthPlayerRemainsReachable2�������:������a"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-tiesHaveJointCrownsAndTheFourthPlayerRemainsReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp8scoreCardsShowPersonalChangeAndSessionAndOfflineBigState2������c:������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-scoreCardsShowPersonalChangeAndSessionAndOfflineBigState.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp8bigScoreboardKeepsScopeAcrossRotationAndClearsWakeOnExit2����Ó:������\"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-bigScoreboardKeepsScopeAcrossRotationAndClearsWakeOnExit.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp*longNamesAndLongSignedScoresRemainReadable2�������]:�����Ƙ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-longNamesAndLongSignedScoresRemainReadable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp1confirmedVoiceRoundCreatesExactlyOneSandboxRecord2�����ϒ�:�����ļ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-confirmedVoiceRoundCreatesExactlyOneSandboxRecord.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp3recognizerResultAndCancelledRecognitionKeepStepSafe2�������:�������C"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-recognizerResultAndCancelledRecognitionKeepStepSafe.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp5cancelKeepsManualFormAndVoicePreviewUsesOriginalRules2�������E:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-cancelKeepsManualFormAndVoicePreviewUsesOriginalRules.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
{
NativeVoiceTest"com.hozefa.threepattipro.nativeapp(recreationRestoresVoiceStepButNeverSaves2��������:�����ؚ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-recreationRestoresVoiceStepButNeverSaves.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp0offlineConfirmationCannotChangeOrSaveManualDraft2�����ᔧ:�����ٺ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-offlineConfirmationCannotChangeOrSaveManualDraft.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
~
OnlineGameTest"com.hozefa.threepattipro.nativeapp,stopDialogUsesButtonsAndAndroidBackCancelsIt2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-stopDialogUsesButtonsAndAndroidBackCancelsIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp2nativeAndEmbeddedAuthRestoreExactlyTheSameIdentity2������ǚ:�����ޅ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-nativeAndEmbeddedAuthRestoreExactlyTheSameIdentity.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
x
OnlineGameTest"com.hozefa.threepattipro.nativeapp'liveUpdatesRetainTheBidControlsAndTable2��������:�������0"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-liveUpdatesRetainTheBidControlsAndTable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
v
OnlineGameTest"com.hozefa.threepattipro.nativeapp%existingNativeHomeContainsOnlineEntry2�������3:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-existingNativeHomeContainsOnlineEntry.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�

OnlineGameTest"com.hozefa.threepattipro.nativeapp.onlineAndManualHistoryExposeTheSameFourActions2��������:�������T"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-onlineAndManualHistoryExposeTheSameFourActions.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp5amountBasedBiddingAndMaximumStateWorkInsideTheSameApk2�������U:�������<"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-amountBasedBiddingAndMaximumStateWorkInsideTheSameApk.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
z
OnlineGameTest"com.hozefa.threepattipro.nativeapp)emptySeatsCanBeChosenWithoutAdminApproval2�������=:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-emptySeatsCanBeChosenWithoutAdminApproval.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp4sharedTableLoadsInsideSamePackageWithSafeWebSettings2�����ɞ�:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-sharedTableLoadsInsideSamePackageWithSafeWebSettings.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
z
OnlineGameTest"com.hozefa.threepattipro.nativeapp(invitationPrefillsRoomCodeInBundledTable2�������:������ƹ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-invitationPrefillsRoomCodeInBundledTable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp/rotationKeepsTheOnlineWebViewAndJavascriptState2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-rotationKeepsTheOnlineWebViewAndJavascriptState.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
ShareIntentTest"com.hozefa.threepattipro.nativeapp6singleAndMultiplePngsReachAnotherUidWithReadPermission2������޾:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.ShareIntentTest-singleAndMultiplePngsReachAnotherUidWithReadPermission.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/testlog/test-results.log 2
text/plain