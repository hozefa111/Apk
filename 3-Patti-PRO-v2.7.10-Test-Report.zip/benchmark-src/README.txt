Local JVM benchmark; this does not measure phone rendering or WAN latency.
Requires Java 17 and the existing org.json:json:20240303 dependency from this Android project's Gradle cache.
Compile (replace /path/to/json.jar with that cached jar):
  javac -cp /path/to/json.jar -d benchmark-classes benchmark-src/com/hozefa/threepattipro/nativeapp/*.java
Run:
  java -cp benchmark-classes:/path/to/json.jar com.hozefa.threepattipro.nativeapp.FetchBenchmark
The baseline DocumentVersion implementation is from the v2.7.9 native source; only its class name changed for side-by-side compilation.
