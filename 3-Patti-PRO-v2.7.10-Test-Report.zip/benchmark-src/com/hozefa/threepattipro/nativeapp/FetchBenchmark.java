package com.hozefa.threepattipro.nativeapp;
import org.json.*;
public final class FetchBenchmark {
 public static void main(String[] args)throws Exception{
  JSONObject[] rows=new JSONObject[2000];
  for(int i=0;i<rows.length;i++)rows[i]=new JSONObject().put("bid",new JSONObject().put("integerValue","155")).put("scoreChanges",new JSONObject().put("mapValue",new JSONObject().put("fields",new JSONObject().put("synthetic",new JSONObject().put("integerValue",String.valueOf(i))))));
  for(int i=0;i<300;i++){BeforeDocumentVersion.of(rows[i]);DocumentVersion.of(rows[i]);}
  JSONArray before=new JSONArray(),after=new JSONArray();
  for(int repeat=0;repeat<5;repeat++){
   long start=System.nanoTime();String[] tokens=new String[rows.length];for(int i=0;i<rows.length;i++)tokens[i]=BeforeDocumentVersion.of(rows[i]);before.put((System.nanoTime()-start)/1e6);
   start=System.nanoTime();for(int i=0;i<rows.length;i++)if(!tokens[i].equals(DocumentVersion.of(rows[i])))throw new AssertionError("Token compatibility");after.put((System.nanoTime()-start)/1e6);
  }
  System.out.println(new JSONObject().put("scope","local JVM synthetic document token benchmark; not device/network latency").put("documents",rows.length).put("beforeMillis",before).put("afterMillis",after).put("allTokensMatch",true).toString(2));
 }
}