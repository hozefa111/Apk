
0�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp:onlineSessionCascadeRemovesLinkedRoundsAndKeepsOtherScores2��������:������O"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-onlineSessionCascadeRemovesLinkedRoundsAndKeepsOtherScores.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp8largeClearRestoreAndInterruptedCommitRecoverAfterRestart2�������[:������ݥ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-largeClearRestoreAndInterruptedCommitRecoverAfterRestart.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp4sdkCodecPreservesAllArchiveTypesAndLiteralFieldNames2�����ᔧ:�������%"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-sdkCodecPreservesAllArchiveTypesAndLiteralFieldNames.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp1clearRequiresCurrentBackupAndCanRestoreEverything2�������':��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-clearRequiresCurrentBackupAndCanRestoreEverything.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp$staleVersionCannotOverwriteNewerEdit2�����Ҫ�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-staleVersionCannotOverwriteNewerEdit.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp.roundRetryAndPayloadConflictAndVersionedDelete2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-roundRetryAndPayloadConflictAndVersionedDelete.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp8externalEditArrivesDirectlyAndOldDialogCannotOverwriteIt2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-externalEditArrivesDirectlyAndOldDialogCannotOverwriteIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp1playerChartAndSelectionsSurviveActivityRecreation2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-playerChartAndSelectionsSurviveActivityRecreation.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp=analyticsControlsAndLongNamesRemainUsableAtLargeFontLandscape2������޾:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-analyticsControlsAndLongNamesRemainUsableAtLargeFontLandscape.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp+sessionScopeAndEmptyHistoryDoNotInventStats2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-sessionScopeAndEmptyHistoryDoNotInventStats.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp0everyAdvancedViewRendersAndKeepsFiltersReachable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-everyAdvancedViewRendersAndKeepsFiltersReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp:fortySevenRoundHistoryUsesCardsAndKeepsEveryRoundReachable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-fortySevenRoundHistoryUsesCardsAndKeepsEveryRoundReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp5largeFontLandscapeKeepsHistoryAndShareActionsOnScreen2�����ǽ�:�������q"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-largeFontLandscapeKeepsHistoryAndShareActionsOnScreen.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp5detailsKeepNegativeAndZeroScoresDistinctWithLongNames2�������r:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-detailsKeepNegativeAndZeroScoresDistinctWithLongNames.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp1motionPreferencePersistsThroughActivityRecreation2�������:�������W"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-motionPreferencePersistsThroughActivityRecreation.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp>systemAnimationOffOverridesFullAndReducedLeavesFinalReadableUi2�������X:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-systemAnimationOffOverridesFullAndReducedLeavesFinalReadableUi.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp<pauseCancelsMotionRestoresFinalScoreAndDoesNotReplayOnResume2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-pauseCancelsMotionRestoresFinalScoreAndDoesNotReplayOnResume.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp7sessionCelebrationCanBeSkippedAndHistoryDoesNotReplayIt2��������:�������r"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-sessionCelebrationCanBeSkippedAndHistoryDoesNotReplayIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp@confirmedLiveSnapshotAnimatesScoresRanksAndNeverReplaysReconnect2�����ܠv:�����ֵ?"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-confirmedLiveSnapshotAnimatesScoresRanksAndNeverReplaysReconnect.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
w
NativeNavigationTest"com.hozefa.threepattipro.nativeapp fullRoundFormSaveAndSharePreview2�������A:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-fullRoundFormSaveAndSharePreview.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeNavigationTest"com.hozefa.threepattipro.nativeapp)restoredLoginDuringDialogShowDoesNotCrash2�����å�:�������|"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-restoredLoginDuringDialogShowDoesNotCrash.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
v
NativeNavigationTest"com.hozefa.threepattipro.nativeappnativeScreensSearchAndSettings2��������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-nativeScreensSearchAndSettings.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeNavigationTest"com.hozefa.threepattipro.nativeapp.navigationAndSettingsRemainUsableWithLargeText2��������:�����Åf"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-navigationAndSettingsRemainUsableWithLargeText.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp5sdkOfflineRestartKeepsSavedTableReadOnlyAndReconnects2�������f:�������H"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-sdkOfflineRestartKeepsSavedTableReadOnlyAndReconnects.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp7oldRestCooldownDoesNotBlockHealthySdkAndNoMinutePolling2�������H:�����Ղ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-oldRestCooldownDoesNotBlockHealthySdkAndNoMinutePolling.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp@quotaCooldownSurvivesRestartAndRefreshThenRecoversWithoutWriting2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-quotaCooldownSurvivesRestartAndRefreshThenRecoversWithoutWriting.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp<quotaScreenReplacesEndlessLoadingAndKeepsCachedTableReadable2������ʷ:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-quotaScreenReplacesEndlessLoadingAndKeepsCachedTableReadable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp2largeTextLandscapeKeepsScoreboardControlsReachable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-largeTextLandscapeKeepsScoreboardControlsReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp7currentSessionWithoutActiveSessionShowsNoInventedScores2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-currentSessionWithoutActiveSessionShowsNoInventedScores.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp6compactPodiumHasNoClippedNamesOrScoresAndOpensProfiles2��������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-compactPodiumHasNoClippedNamesOrScoresAndOpensProfiles.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp5tiesHaveJointCrownsAndTheFourthPlayerRemainsReachable2�������:������˨"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-tiesHaveJointCrownsAndTheFourthPlayerRemainsReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp8scoreCardsShowPersonalChangeAndSessionAndOfflineBigState2��������:�����ܩ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-scoreCardsShowPersonalChangeAndSessionAndOfflineBigState.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp8bigScoreboardKeepsScopeAcrossRotationAndClearsWakeOnExit2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-bigScoreboardKeepsScopeAcrossRotationAndClearsWakeOnExit.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp*longNamesAndLongSignedScoresRemainReadable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-longNamesAndLongSignedScoresRemainReadable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp1confirmedVoiceRoundCreatesExactlyOneSandboxRecord2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-confirmedVoiceRoundCreatesExactlyOneSandboxRecord.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp3recognizerResultAndCancelledRecognitionKeepStepSafe2��������:������Ɗ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-recognizerResultAndCancelledRecognitionKeepStepSafe.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp5cancelKeepsManualFormAndVoicePreviewUsesOriginalRules2�������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-cancelKeepsManualFormAndVoicePreviewUsesOriginalRules.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
z
NativeVoiceTest"com.hozefa.threepattipro.nativeapp(recreationRestoresVoiceStepButNeverSaves2�������:������ڑ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-recreationRestoresVoiceStepButNeverSaves.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp0offlineConfirmationCannotChangeOrSaveManualDraft2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-offlineConfirmationCannotChangeOrSaveManualDraft.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp2nativeAndEmbeddedAuthRestoreExactlyTheSameIdentity2��������:�����譔"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-nativeAndEmbeddedAuthRestoreExactlyTheSameIdentity.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
w
OnlineGameTest"com.hozefa.threepattipro.nativeapp%existingNativeHomeContainsOnlineEntry2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-existingNativeHomeContainsOnlineEntry.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp.onlineAndManualHistoryExposeTheSameFourActions2�����ҁ�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-onlineAndManualHistoryExposeTheSameFourActions.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp5amountBasedBiddingAndMaximumStateWorkInsideTheSameApk2��������:������ř"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-amountBasedBiddingAndMaximumStateWorkInsideTheSameApk.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
{
OnlineGameTest"com.hozefa.threepattipro.nativeapp)emptySeatsCanBeChosenWithoutAdminApproval2�����ͭ�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-emptySeatsCanBeChosenWithoutAdminApproval.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp4sharedTableLoadsInsideSamePackageWithSafeWebSettings2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-sharedTableLoadsInsideSamePackageWithSafeWebSettings.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
z
OnlineGameTest"com.hozefa.threepattipro.nativeapp(invitationPrefillsRoomCodeInBundledTable2�������:������ٗ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-invitationPrefillsRoomCodeInBundledTable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp/rotationKeepsTheOnlineWebViewAndJavascriptState2��������:�������M"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-rotationKeepsTheOnlineWebViewAndJavascriptState.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo�
�
ShareIntentTest"com.hozefa.threepattipro.nativeapp6singleAndMultiplePngsReachAnotherUidWithReadPermission2������O:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/logcat-com.hozefa.threepattipro.nativeapp.ShareIntentTest-singleAndMultiplePngsReachAnotherUidWithReadPermission.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 15/testlog/test-results.log 2
text/plain