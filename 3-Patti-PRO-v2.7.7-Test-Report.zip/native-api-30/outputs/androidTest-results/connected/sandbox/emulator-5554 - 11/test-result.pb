
0�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp:onlineSessionCascadeRemovesLinkedRoundsAndKeepsOtherScores2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-onlineSessionCascadeRemovesLinkedRoundsAndKeepsOtherScores.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp8largeClearRestoreAndInterruptedCommitRecoverAfterRestart2��������:������ܫ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-largeClearRestoreAndInterruptedCommitRecoverAfterRestart.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp4sdkCodecPreservesAllArchiveTypesAndLiteralFieldNames2�����ғ�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-sdkCodecPreservesAllArchiveTypesAndLiteralFieldNames.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp1clearRequiresCurrentBackupAndCanRestoreEverything2������ǚ:�������m"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-clearRequiresCurrentBackupAndCanRestoreEverything.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp$staleVersionCannotOverwriteNewerEdit2�������o:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-staleVersionCannotOverwriteNewerEdit.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp.roundRetryAndPayloadConflictAndVersionedDelete2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-roundRetryAndPayloadConflictAndVersionedDelete.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
FirebaseGatewayEmulatorTest"com.hozefa.threepattipro.nativeapp8externalEditArrivesDirectlyAndOldDialogCannotOverwriteIt2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.FirebaseGatewayEmulatorTest-externalEditArrivesDirectlyAndOldDialogCannotOverwriteIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp1playerChartAndSelectionsSurviveActivityRecreation2��������:�������6"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-playerChartAndSelectionsSurviveActivityRecreation.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp=analyticsControlsAndLongNamesRemainUsableAtLargeFontLandscape2�������8:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-analyticsControlsAndLongNamesRemainUsableAtLargeFontLandscape.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp+sessionScopeAndEmptyHistoryDoNotInventStats2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-sessionScopeAndEmptyHistoryDoNotInventStats.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeAnalyticsTest"com.hozefa.threepattipro.nativeapp0everyAdvancedViewRendersAndKeepsFiltersReachable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeAnalyticsTest-everyAdvancedViewRendersAndKeepsFiltersReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp:fortySevenRoundHistoryUsesCardsAndKeepsEveryRoundReachable2������Ճ:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-fortySevenRoundHistoryUsesCardsAndKeepsEveryRoundReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp5largeFontLandscapeKeepsHistoryAndShareActionsOnScreen2��������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-largeFontLandscapeKeepsHistoryAndShareActionsOnScreen.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeDialogTest"com.hozefa.threepattipro.nativeapp5detailsKeepNegativeAndZeroScoresDistinctWithLongNames2������՜:������߯"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeDialogTest-detailsKeepNegativeAndZeroScoresDistinctWithLongNames.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp1motionPreferencePersistsThroughActivityRecreation2��������:�������4"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-motionPreferencePersistsThroughActivityRecreation.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp>systemAnimationOffOverridesFullAndReducedLeavesFinalReadableUi2�������6:�������^"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-systemAnimationOffOverridesFullAndReducedLeavesFinalReadableUi.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp<pauseCancelsMotionRestoresFinalScoreAndDoesNotReplayOnResume2�������_:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-pauseCancelsMotionRestoresFinalScoreAndDoesNotReplayOnResume.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp7sessionCelebrationCanBeSkippedAndHistoryDoesNotReplayIt2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-sessionCelebrationCanBeSkippedAndHistoryDoesNotReplayIt.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeMotionTest"com.hozefa.threepattipro.nativeapp@confirmedLiveSnapshotAnimatesScoresRanksAndNeverReplaysReconnect2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeMotionTest-confirmedLiveSnapshotAnimatesScoresRanksAndNeverReplaysReconnect.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
w
NativeNavigationTest"com.hozefa.threepattipro.nativeapp fullRoundFormSaveAndSharePreview2��������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-fullRoundFormSaveAndSharePreview.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeNavigationTest"com.hozefa.threepattipro.nativeapp)restoredLoginDuringDialogShowDoesNotCrash2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-restoredLoginDuringDialogShowDoesNotCrash.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
v
NativeNavigationTest"com.hozefa.threepattipro.nativeappnativeScreensSearchAndSettings2��������:�����ۤ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-nativeScreensSearchAndSettings.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeNavigationTest"com.hozefa.threepattipro.nativeapp.navigationAndSettingsRemainUsableWithLargeText2��������:�������6"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeNavigationTest-navigationAndSettingsRemainUsableWithLargeText.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp5sdkOfflineRestartKeepsSavedTableReadOnlyAndReconnects2�������7:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-sdkOfflineRestartKeepsSavedTableReadOnlyAndReconnects.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp7oldRestCooldownDoesNotBlockHealthySdkAndNoMinutePolling2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-oldRestCooldownDoesNotBlockHealthySdkAndNoMinutePolling.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp@quotaCooldownSurvivesRestartAndRefreshThenRecoversWithoutWriting2��������:������Ȕ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-quotaCooldownSurvivesRestartAndRefreshThenRecoversWithoutWriting.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeQuotaTest"com.hozefa.threepattipro.nativeapp<quotaScreenReplacesEndlessLoadingAndKeepsCachedTableReadable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeQuotaTest-quotaScreenReplacesEndlessLoadingAndKeepsCachedTableReadable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp2largeTextLandscapeKeepsScoreboardControlsReachable2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-largeTextLandscapeKeepsScoreboardControlsReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp7currentSessionWithoutActiveSessionShowsNoInventedScores2������˘:�����ޓ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-currentSessionWithoutActiveSessionShowsNoInventedScores.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp6compactPodiumHasNoClippedNamesOrScoresAndOpensProfiles2��������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-compactPodiumHasNoClippedNamesOrScoresAndOpensProfiles.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp5tiesHaveJointCrownsAndTheFourthPlayerRemainsReachable2������̉:�����ֹ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-tiesHaveJointCrownsAndTheFourthPlayerRemainsReachable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp8scoreCardsShowPersonalChangeAndSessionAndOfflineBigState2�����譔:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-scoreCardsShowPersonalChangeAndSessionAndOfflineBigState.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp8bigScoreboardKeepsScopeAcrossRotationAndClearsWakeOnExit2������߀:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-bigScoreboardKeepsScopeAcrossRotationAndClearsWakeOnExit.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeScoreboardTest"com.hozefa.threepattipro.nativeapp*longNamesAndLongSignedScoresRemainReadable2��������:�������c"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeScoreboardTest-longNamesAndLongSignedScoresRemainReadable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp1confirmedVoiceRoundCreatesExactlyOneSandboxRecord2�������e:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-confirmedVoiceRoundCreatesExactlyOneSandboxRecord.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp3recognizerResultAndCancelledRecognitionKeepStepSafe2�����Î�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-recognizerResultAndCancelledRecognitionKeepStepSafe.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp5cancelKeepsManualFormAndVoicePreviewUsesOriginalRules2��������:�������J"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-cancelKeepsManualFormAndVoicePreviewUsesOriginalRules.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
z
NativeVoiceTest"com.hozefa.threepattipro.nativeapp(recreationRestoresVoiceStepButNeverSaves2�����ǫK:�����Ϳ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-recreationRestoresVoiceStepButNeverSaves.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
NativeVoiceTest"com.hozefa.threepattipro.nativeapp0offlineConfirmationCannotChangeOrSaveManualDraft2��������:�������!"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.NativeVoiceTest-offlineConfirmationCannotChangeOrSaveManualDraft.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp2nativeAndEmbeddedAuthRestoreExactlyTheSameIdentity2�������#:�����ɰ�"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-nativeAndEmbeddedAuthRestoreExactlyTheSameIdentity.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
w
OnlineGameTest"com.hozefa.threepattipro.nativeapp%existingNativeHomeContainsOnlineEntry2�����Ҫ�:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-existingNativeHomeContainsOnlineEntry.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp.onlineAndManualHistoryExposeTheSameFourActions2��������:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-onlineAndManualHistoryExposeTheSameFourActions.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp5amountBasedBiddingAndMaximumStateWorkInsideTheSameApk2��������:������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-amountBasedBiddingAndMaximumStateWorkInsideTheSameApk.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
z
OnlineGameTest"com.hozefa.threepattipro.nativeapp)emptySeatsCanBeChosenWithoutAdminApproval2�������:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-emptySeatsCanBeChosenWithoutAdminApproval.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp4sharedTableLoadsInsideSamePackageWithSafeWebSettings2��������:������O"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-sharedTableLoadsInsideSamePackageWithSafeWebSettings.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
y
OnlineGameTest"com.hozefa.threepattipro.nativeapp(invitationPrefillsRoomCodeInBundledTable2�������[:��������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-invitationPrefillsRoomCodeInBundledTable.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
OnlineGameTest"com.hozefa.threepattipro.nativeapp/rotationKeepsTheOnlineWebViewAndJavascriptState2��������:�����ꀇ"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.OnlineGameTest-rotationKeepsTheOnlineWebViewAndJavascriptState.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo�
�
ShareIntentTest"com.hozefa.threepattipro.nativeapp6singleAndMultiplePngsReachAnotherUidWithReadPermission2�����:�������"�

logcatandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/logcat-com.hozefa.threepattipro.nativeapp.ShareIntentTest-singleAndMultiplePngsReachAnotherUidWithReadPermission.txt"�

device-infoandroid�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/device-info.pb"�

device-info.meminfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/meminfo"�

device-info.cpuinfoandroid~
|/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/cpuinfo*�
c
test-results.logOcom.google.testing.platform.runtime.android.driver.AndroidInstrumentationDriver�
�/home/runner/work/Apk/Apk/3PattiProNative/app/build/outputs/androidTest-results/connected/sandbox/emulator-5554 - 11/testlog/test-results.log 2
text/plain